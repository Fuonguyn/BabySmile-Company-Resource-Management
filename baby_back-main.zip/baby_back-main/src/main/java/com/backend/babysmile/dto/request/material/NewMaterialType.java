package com.backend.babysmile.dto.request.material;

public record NewMaterialType(
        String material_type_name
) {
}
