package com.backend.babysmile.dto.respond.material;

public record TypeData(
        Integer type_id,
        String type_name
) {

}
