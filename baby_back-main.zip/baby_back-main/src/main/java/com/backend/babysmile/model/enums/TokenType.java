package com.backend.babysmile.model.enums;


public enum TokenType {
    BEARER
}
