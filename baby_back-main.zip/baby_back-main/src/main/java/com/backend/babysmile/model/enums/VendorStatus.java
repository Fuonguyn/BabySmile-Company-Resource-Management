package com.backend.babysmile.model.enums;

public enum VendorStatus {
    ACTIVE(0),
    INACTIVE(1),
    INORDER(2);
    VendorStatus(int val){

    }
}
