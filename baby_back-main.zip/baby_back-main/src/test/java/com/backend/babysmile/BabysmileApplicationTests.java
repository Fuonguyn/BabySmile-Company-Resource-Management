package com.backend.babysmile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BabysmileApplicationTests {

	@Test
	void contextLoads() {
	}

}
