import React from 'react';

const Sidebar = () => {
  return (
    <div className="bg-gray-800 h-screen w-64">
      {/* Sidebar content */}
    </div>
  );
};

export default Sidebar;
